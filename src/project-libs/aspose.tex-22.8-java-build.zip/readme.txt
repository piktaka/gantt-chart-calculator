﻿
Aspose.TeX for Java, TeX Typesetting Solution
==========================================================================

This distribution contains the following directories:

- lib      : the jar, compiled and ready to use version for JDK 1.6 or higher.
           : aspose-tex-<version>.jar

- javadoc  : the documentation in html format related to Aspose.TeX for Java.


To get started using Aspose.TeX for Java, please visit: https://docs.aspose.com/tex/java/getting-started/


http://www.aspose.com/
© Aspose 2002-2022. All Rights Reserved.